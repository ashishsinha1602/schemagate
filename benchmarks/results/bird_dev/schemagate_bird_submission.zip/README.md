# schemagate + Claude Opus 5.5 — BIRD test-set submission

Team: Ashish Sinha (independent). Method: **schemagate** (open source, Apache-2.0, https://github.com/ashishsinha1602/schemagate).

## What the method does, per question

1. schemagate reflects the question's SQLite database and indexes its tables (BM25 over names, DDL and
   sampled values of short text columns; foreign keys inferred).
2. It selects the tables the question needs (top 8) and builds a prompt holding only their DDL plus the
   `database_description/*.csv` notes for those tables.
3. Claude Opus 5.5 (Anthropic API, temperature 0) writes one SQLite query from the question and its
   `evidence` hint.
4. The query is run on the database. If SQLite raises an error, the model sees the error and corrects the
   query, up to 3 times. If the model declines, it is asked once for its best reading.
5. Nothing reads the gold SQL. The test file's empty `SQL` field is never touched.

Budget: --max-calls 2400 stops the run after 2,400 model calls (1,789 questions plus repairs); --max-tokens 4000 caps each reply. Logging and resume: predictions are written after every question; re-running the same command skips
questions already in the output file, so evaluation resumes from the failing example.

## Run

```
pip install -r requirements.txt
export ANTHROPIC_API_KEY=...            # the key we provide; reset it after evaluation
python bird_run.py --questions /path/to/test.json --db-root /path/to/test_databases \
    --out predict_test.json --model claude-opus-5-5 --workers 6 --max-tokens 4000 --max-calls 2400
```

`--questions` is the BIRD question file (`dev.json` or `test.json`); `--db-root` holds one folder per
`db_id` with `<db_id>.sqlite` and `database_description/`. Output is BIRD's format:
`{"0": "<sql>\t----- bird -----\t<db_id>", ...}` in question order.

Dev run: `python bird_run.py --questions dev.json --db-root dev_databases --out predict_dev.json`.

## Resources

- CPU only; no GPU. One API call per question, plus a repair call for roughly 5% of questions.
- Prompt size: see the figure in the submission email (measured on the dev set).
- `column_meaning.json`: **not used**. The method reads the `database_description` CSVs shipped with each
  database folder, nothing else.
- No third-party service receives the databases: the only outbound traffic is the prompt (selected DDL,
  column notes, question) to the Anthropic API.

## Files

- `bird_run.py` — the runner (standalone copy of `benchmarks/bird_minidev.py` from schemagate 1.10.0)
- `requirements.txt`
- `predict_dev.json` — our dev-set predictions (1,534)
- `predict_dev.ex.txt` — output of `evaluation_ex.py` on them
